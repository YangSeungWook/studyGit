import React, { useRef, useState, useEffect } from 'react';
import Modal from './Modal';
import Menu from './Menu';
import './App.css';
import * as common from "./common.js";
import axios from 'axios';


const App = () => {

  const [popModal, setPopModal] = useState('')
  const [popMenu, setPopMenu] = useState('')
  const [good, setGood] = useState('')


  //팝업호출 함수
  const alertOpen = (content, effect) => {
    setPopModal(<Modal text={content} effect={effect} close={alertClose} />)
    common.ysw();
  }

  //팝업제거 함수
  const alertClose = () => {
    setPopModal('');
  }


  useEffect(() => {

  }, [])

  const axiosGo = () => {
    axios({
      method: 'get',
      url: './ysw.json',
      //params: { id: 1 }
    })
      .then(function (response) {
        console.log(response);
        setGood(response.data.ysw)
      })
      .catch(function (error) {
      });
  }



return (
  <div className="App">

    <h1>팝업리스트</h1>

    <div className="popupList">
      <ul>
        <li>
          <button onClick={() => alertOpen('난 FadeUp 팝업!', 'fadeUp')}>fadeUp 팝업</button>
        </li>
        <li>
          <button onClick={() => alertOpen('난 FadeRight 팝업!', 'fadeRight')}>fadeRight 팝업</button>
        </li>
        <li>
          <button onClick={() => alertOpen('난 Opaicty 팝업!', 'opaicty')}>Opaicty 팝업</button>
        </li>
      </ul>
    </div>

    <button className="axiosBtn" onClick={() => { axiosGo() }}>호출!</button>
    {good}

    {popModal}


    <Menu />

  </div>
);
}

export default App;
